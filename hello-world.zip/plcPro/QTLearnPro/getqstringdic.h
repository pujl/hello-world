#ifndef GETQSTRINGDIC_H
#define GETQSTRINGDIC_H

#include <QString>
#include "commen.h"

class getQStringDic
{
public:
    static QString  GetDevName(unsigned int nId);
};

#endif // GETQSTRINGDIC_H
